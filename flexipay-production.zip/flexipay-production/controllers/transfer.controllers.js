import User from '../models/user/userModel.js';
import Transfer from "../models/others/transferModel.js"
import { NIGERIAN_BANKS } from '../utils/banks.js';
import fetch from 'node-fetch';



const paylonytransferUrl= 'https://api.paylony.com/api/v1/bank_transfer'
const paylonyToken = process.env.PAYLONY_SECRET_KEY;



const PAYLONY_VERIFY_URL = 'https://api.paylony.com/api/v1/account_name';
const PAYLONY_TOKEN = process.env.PAYLONY_SECRET_KEY;





/**
 * @swagger
 * /api/transfer/transferfunds:
 *   post:
 *     summary: Transfer funds from wallet to an external bank account via Paylony
 *     description: >
 *       Deducts the amount from the wallet immediately, creates a pending Transfer
 *       record, then calls Paylony's bank_transfer API. Note: on failure the rollback
 *       currently references an undefined `airtime` variable — this endpoint has a
 *       known bug where failed transfers may not correctly roll back wallet balance.
 *     tags: [Transfer]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [account_number, amount, bank_code]
 *             properties:
 *               account_number:
 *                 type: string
 *                 example: "0123456789"
 *               amount:
 *                 type: number
 *                 example: 10000
 *               narration:
 *                 type: string
 *                 example: "Payment for services"
 *               bank_code:
 *                 type: string
 *                 example: "044"
 *     responses:
 *       200:
 *         description: Transfer successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 amount:
 *                   type: number
 *       400:
 *         description: Sender name not found, invalid amount, or insufficient balance
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: Transfer failed
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */


export const transferFunds = async (req, res) => {
  let transfer;
  try {
    const { account_number, amount, narration, bank_code } = req.body;

    const user = await User.findOne({ email: req.user.email });
    if (!user) return res.status(404).json({ error: 'User not found' });

    const sender_name = user.first_name || user.fullName;
    if (!sender_name) {
      return res.status(400).json({ message: 'sender name not found' });
    }

    if (!account_number || !bank_code) {
      return res.status(400).json({ error: 'Account number and bank code are required' });
    }

    const reference = `mcd_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }
    if (user.wallet.balance < parsedAmount) {
      return res.status(400).json({ error: 'Insufficient wallet balance' });
    }

    transfer = new Transfer({
      userId: user._id,
      amount: parsedAmount,
      account_number,
      bank_code,
      narration: narration || 'Wallet transfer',
      ref: reference,
    });

    await transfer.save();

    user.wallet.balance -= parsedAmount;
    await user.save();

    const response = await fetch(`${paylonytransferUrl}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${paylonyToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId: user._id,
        amount: parsedAmount,
        account_number,
        bank_code,
        ref: reference,
        sender_name,
      }),
    });

    if (!response.ok) {
      // Roll back wallet balance and update transaction status
      user.wallet.balance += parsedAmount;
      transfer.status = 'failed';
      await Promise.all([user.save(), transfer.save()]);
      throw new Error(`MCD API error: ${response.status}`);
    }

    const result = await response.json();
    console.log(result);
    transfer.status = 'success';
    await transfer.save();
    user.wallet.transactions.push({
      type: 'debit',
      amount: parsedAmount,
      provider: 'paylony',
      reference,
      status: 'success',
      details: { account_number, bank_code, type: 'transfer' },
      timestamp: new Date(),
    });
    await user.save();

    res.json({ message: 'Transfer successful', amount });
  } catch (error) {
    console.error('Transfer error:', error);
    res.status(500).json({ error: `Transfer failed: ${error.message}` });
  }
};




const PAYLONY_WHITELIST = [
  "011", "033", "035", "044", "050", "057", "058",
  "070", "076", "082", "214", "221", "232"
];

// Only the subset of banks Paylony actually supports transfers to — the client needs
// this to build the bank picker instead of guessing/duplicating the whitelist.
export const getBanks = async (req, res) => {
  try {
    const banks = NIGERIAN_BANKS
      .filter((b) => PAYLONY_WHITELIST.includes(b.code))
      .map((b) => ({ name: b.name, code: b.code }));
    res.json({ banks });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch banks' });
  }
};



/**
 * @swagger
 * /api/transfer/verify-account:
 *   post:
 *     summary: Verify a bank account name before transferring funds
 *     description: >
 *       Only supports a whitelisted set of banks for Paylony transfers
 *       (GTBank, Access, Zenith, UBA, First Bank, and others in PAYLONY_WHITELIST).
 *     tags: [Transfer]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [bank_code, account_number]
 *             properties:
 *               bank_code:
 *                 type: string
 *                 example: "058"
 *               account_number:
 *                 type: string
 *                 example: "0123456789"
 *     responses:
 *       200:
 *         description: Account verified
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 account_name:
 *                   type: string
 *                 account_number:
 *                   type: string
 *                 bank_name:
 *                   type: string
 *                 bank_code:
 *                   type: string
 *       400:
 *         description: Missing fields, invalid/unsupported bank, or invalid account
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: Service temporarily unavailable
 */


export const verifyAccount = async (req, res) => {
  try {
    const { bank_code, account_number } = req.body;

    if (!bank_code || !account_number) {
      return res.status(400).json({ error: 'Bank code and account number required' });
    }

    const bank = NIGERIAN_BANKS.find(b => b.code === bank_code);
    if (!bank) {
      return res.status(400).json({ error: 'Invalid bank selected' });
    }

    if (!PAYLONY_WHITELIST.includes(bank_code)) {
      return res.status(400).json({
        error: "This bank is not yet supported for transfers. Please use GTBank, Access, Zenith, UBA, First Bank, etc."
      });
    }

    const response = await fetch(PAYLONY_VERIFY_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${PAYLONY_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        bank_code: bank_code,
        account_number: account_number,
      }),
    });

    const data = await response.json();
    console.log('Paylony response:', data);

    if (!response.ok || data.success === false) {
      return res.status(400).json({
        error: data.message || 'Invalid account number or bank not supported',
      });
    }

    res.json({
      account_name: data.account_name,
      account_number: data.account_number || account_number,
      bank_name: bank.name,
      bank_code: bank_code,
    });

  } catch (err) {
    console.error('account verification error oocurred ', err);
    res.status(500).json({ error: 'Service temporarily unavailable' });
  }
};
