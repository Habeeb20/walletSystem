import express from "express"

import cors from "cors";
import dotenv from "dotenv";
import morgan from "morgan";

import connectDB from "./db.js";
import jwt from "jsonwebtoken"
import { configureHelmet } from "./utils/security.js";
import router from "./routes/user.route.js";
import airtimerouter from "./routes/airtime.route.js";
import walletrouter from "./routes/wallet.route.js";
import electricityRouter from "./routes/electricty.route.js";
import tvSubRoute from "./routes/tv.route.js";
import transferRouter from "./routes/transferRoute.js"
import contactRoutes from "./routes/contactRoutes.js"
import User from "./models/user/userModel.js"
import adminRouter from './routes/AdminRoutes.js';
// server.js / app.js
import swaggerUi from "swagger-ui-express";
import { swaggerSpec } from "./utils/swagger.js";



dotenv.config();

const requiredEnvVars = ["JWT_SECRET", "MONGO_URI"];
const missingEnvVars = requiredEnvVars.filter((key) => !process.env[key]);
if (missingEnvVars.length > 0) {
  console.error(`Missing required environment variables: ${missingEnvVars.join(", ")}`);
  process.exit(1);
}

connectDB()


///**********   ROUTES   ******** */



const app = express();

configureHelmet(app)

app.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  res.set('Surrogate-Control', 'no-store');
  next();
});





// Middleware
app.use(express.json({ limit: "10mb" }));

app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cors({
  origin: ["http://localhost:5173","http://localhost:5174",  "http://localhost:5175",  "https://wallet.taskflow.com.ng", ] ,
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true,
}));
app.use(morgan("dev"));





app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
// Routes
app.get("/", (req, res) => {
  res.send("wallet backend is running on port....");
});


app.use("/api/auth", router)
app.use("/api/wallet", walletrouter)
app.use("/api/airtime", airtimerouter)
app.use("/api/electricty", electricityRouter)
app.use("/api/tv", tvSubRoute)
app.use("/api/transfer", transferRouter)
app.use("/api/contact", contactRoutes)
app.use('/api/admin', adminRouter);
// Error handling
app.use((err, req, res, next) => {
  console.error("Error:", err.stack);
  res.status(500).json({ status: false, message: "Internal server error" });
});


// await User.create({
//     fullName: 'Habeeb',

//   email: 'Abeeb@gmail.com',
//   password: 'Waliyu@bib',

// });

// console.log('Superadmin created!');






// Start server
const port = process.env.PORT || 8080;

app.listen(port, async () => {
  console.log(`Server is running on port ${port}`);

})
































