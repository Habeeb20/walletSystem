import express from "express"
import { authenticateToken, loginRateLimiter, resetPasswordLimiter, resetPasswordSubmitLimiter, verifyEmailLimiter, validateRegisterInput, validationResetPasswordInput } from "../utils/security.js"
import { changePassword, checkVirtualAccount, createPaylonyUserVirtualAccount, createUserVirtualAccount, fetchDashboard, getBiometricChallenge, getCustomerDetails, initiateResetPassword, loginWithBiometrics, loginWithPassword, logout, register, registerBiometrics, resendVerificationEmail, resetPassword, selectUsername, verifyEmail } from "../controllers/user.controller.js"

const router = express.Router()

router.post('/register', validateRegisterInput, register)
router.post('/select-username', authenticateToken, selectUsername)
router.post('/verifyemail', verifyEmailLimiter, verifyEmail)
router.post('/resend-verification', verifyEmailLimiter, resendVerificationEmail)
router.post('/login', loginRateLimiter, loginWithPassword)
router.post('/logout', authenticateToken, logout)
router.post('/change-password', authenticateToken, changePassword)
router.get("/dashboard", authenticateToken, fetchDashboard)
router.post('/biometric-challenge', loginRateLimiter, getBiometricChallenge)
router.post('/biometric-login', loginRateLimiter, loginWithBiometrics)
router.post('/biometric-register', authenticateToken, registerBiometrics)
router.post('/reset-password/initiate', resetPasswordLimiter, initiateResetPassword)
router.post('/reset-password', resetPasswordSubmitLimiter, validationResetPasswordInput, resetPassword)
router.get('/customer', authenticateToken, getCustomerDetails)
router.post('/create-virtual-account', authenticateToken, createUserVirtualAccount)
router.post('/create-paylony-virtual-account', authenticateToken,  createPaylonyUserVirtualAccount)
router.get('/check-virtual-account', authenticateToken, checkVirtualAccount);

export default router


