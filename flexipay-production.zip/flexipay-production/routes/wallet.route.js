import express from "express";
import { authenticateToken } from "../utils/security.js";
import { checkBalancePaystack, fetchAndUpdateWalletBalance, fetchPaylonyAccounts, fundWallet, PaylonyWebhook, walletCallback } from "../controllers/wallet.controller.js";


const router = express.Router();


router.post('/fund-wallet', authenticateToken, fundWallet)
router.get('/callback', walletCallback)
router.get('/wallet-balance', authenticateToken, fetchAndUpdateWalletBalance);
router.get('/fetch-paylony-accounts', authenticateToken, fetchPaylonyAccounts)
// Note: idempotent webhook handler (checks for duplicate reference before crediting)
router.post('/webhook/paylony', PaylonyWebhook);
router.get('/fetch-and-update-balance/:reference/:provider', authenticateToken, fetchAndUpdateWalletBalance);
router.get('/check-balance', authenticateToken, checkBalancePaystack);


export default router;





// https://walletsystem-3.onrender.com/api/wallet/webhook/paylony
