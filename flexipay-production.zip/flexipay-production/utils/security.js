
import jwt from "jsonwebtoken"
import crypto from "crypto"
import helmet from "helmet"
import bcrypt from "bcrypt"
import dotenv from "dotenv"
import rateLimit from "express-rate-limit"
import nodemailer from "nodemailer"
import {validationResult, body} from "express-validator"
import RevokedToken from "../models/revokedToken.js"
dotenv.config()

const JWT_SECRET = process.env.JWT_SECRET
const EMAIL_USER = process.env.EMAIL_USER;
const EMAIL_PASS = process.env.EMAIL_PASS;


//hash password

export async function hashPassword(password) {
    try {
        const saltRounds = 10;
        return await bcrypt.hash(password, saltRounds)
    } catch (error) {
        console.log(error)
        throw new Error("password hashing failed" + error.message)
    }
}




//verify a password

export async function verifyPassword(password, hashedPassword) {
    try {
        return await bcrypt.compare(password, hashedPassword)
    } catch (error) {
        throw new Error("password verification failed" + error.message)
    }
}


///generate 4 digit code

export function generate4DigitCode(){
    try {
        return crypto.randomInt(0, 1000).toString().padStart(4, '0')
    } catch (error) {
        throw new Error('generating 4 digit code failed' + error.message)
    }
}



export async function sendEmailVerificationCode(email, code) {
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail', // Use your email service
      auth: {
        user: EMAIL_USER,
        pass: EMAIL_PASS,
      },
    });

    await transporter.sendMail({
      from: `"Flexipay" <${EMAIL_USER}>`,
      to: email,
      subject: 'Verify Your Email',
      text: `Your verification code is: ${code}`,
      html: `<p>Your verification code is: <strong>${code}</strong></p>`,
    });
  } catch (error) {
    console.log(error)
    throw new Error('Failed to send verification email: ' + error.message);
  }
}



// Generate three unique username suggestions
export async function generateUsernameSuggestions(fullName, User) {
  try {
    const nameParts = fullName.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/);
    const suggestions = [];
    
    const base1 = nameParts[0] || 'user';
    const base2 = nameParts.length > 1 ? nameParts[0] + nameParts[1][0] : base1;
    const base3 = nameParts.length > 1 ? nameParts.join('') : base1 + generate4DigitCode();

    for (let base of [base1, base2, base3]) {
      let username = base;
      let counter = 0;
      while (await User.findOne({ username })) {
        counter++;
        username = `${base}${counter}`;
      }
      suggestions.push(username);
    }

    return suggestions;
  } catch (error) {
    console.log(error)
    throw new Error('Username generation failed: ' + error.message);
  }
}

// Input validation for email verification
export const validateEmailVerificationInput = [
  body('email').isEmail().withMessage('Invalid email address'),
  body('code').isLength({ min: 4, max: 4 }).withMessage('Code must be 4 digits'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  },
];

///generate a jwt token (carries a jti so it can be individually revoked on logout)

export function generateJwtToken(userId, email) {
  try {
    const jti = crypto.randomUUID();
    return jwt.sign({ id: userId, email: email, jti }, JWT_SECRET, { expiresIn: '7d' });
  } catch (error) {
    throw new Error("token generation failed" + error.message)
  }
}

// Generate a single-use, short-lived challenge for biometric login (returned to the client,
// stored hashed on the user document so a DB leak doesn't hand out valid challenges)
export function generateBiometricChallenge() {
  return crypto.randomBytes(32).toString('hex');
}

// Verify an Ed25519 signature over a challenge, produced by the device's keypair.
// Ed25519 (rather than ECDSA) because the client's pure-Dart crypto library only has a
// working cross-platform (Android + iOS) implementation for Ed25519 — its ECDSA path
// depends on a native plugin that's iOS-only, which would leave Android biometric login
// permanently broken. Client encodes the public key as an OKP JWK.
export function verifyBiometricSignature(publicKeyJwk, challenge, signatureBase64) {
  try {
    const publicKey = crypto.createPublicKey({ key: publicKeyJwk, format: 'jwk' });
    return crypto.verify(
      null,
      Buffer.from(challenge, 'utf8'),
      publicKey,
      Buffer.from(signatureBase64, 'base64')
    );
  } catch (error) {
    console.error('Biometric signature verification error:', error.message);
    return false;
  }
}



// Rate limiter for login attempts
export const loginRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit to 5 requests per window
  message: 'Too many login attempts, please try again later.',
});



export const validateRegisterInput = [
  body('email').isEmail().withMessage('Invalid email address'),
  body('password')
    .isLength({ min: 8 })
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
    .withMessage('Password must be at least 8 characters, with uppercase, lowercase, number, and special character'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const errorMessages = errors.array().map(err => err.msg).join(', ');
      return res.status(400).json({ error: errorMessages });
    }
    next();
  },
];
// Input validation for transactions
export const validateTransactionInput = [
  body('amount').isFloat({ min: 0.01 }).withMessage('Amount must be greater than 0'),
  body('recipient').notEmpty().withMessage('Recipient address is required'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  },
];

// Configure Helmet for secure headers
export function configureHelmet(app) {
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
      },
    },
    hsts: { maxAge: 31536000, includeSubDomains: true }, // 1 year
    noSniff: true,
    xssFilter: true,
  }));
}

// Middleware to authenticate JWT. Also rejects tokens whose jti has been revoked (logout).
export async function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.jti) {
      const revoked = await RevokedToken.findOne({ jti: decoded.jti });
      if (revoked) {
        return res.status(403).json({ error: 'Token has been revoked' });
      }
    }
    req.user = decoded;
    next();
  } catch (error) {
    console.log('Token verification failed:', error.message);
    res.status(403).json({ error: 'Invalid or expired token' });
  }
}

// Rate limiter for email verification code submission (4-digit code = 10,000 combinations)
export const verifyEmailLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: 'Too many verification attempts, please try again later.',
});

// Rate limiter for the actual reset-password submission (was previously unlimited,
// letting an attacker brute-force the 4-digit code)
export const resetPasswordSubmitLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: 'Too many password reset attempts, please try again later.',
});


export const validationResetPasswordInput = [
  body('email').isEmail().withMessage('invalid email address'),
  body('code').isLength({min: 4, max:4}).withMessage('code must be 4 digits'),
    body('newPassword')
    .isLength({ min: 8 })
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
    .withMessage('New password must be at least 8 characters, with uppercase, lowercase, number, and special character'),
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  },
]


export const resetPasswordLimiter = rateLimit({
  windowMs: 15 * 60 *1000,
  max:3,
  message:'Too many password reset requests, please try again later'
})






const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com', 
  port: parseInt(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER, 
    pass: process.env.EMAIL_PASS, 
  },
  tls: {
    rejectUnauthorized: false,
  },
});


export const sendContactEmail = async ({
  fromName,
  fromEmail,
  phone,
  subject,
  message,
}) => {
  try {
    const mailOptions = {
      from: `"Contact Form" <${process.env.EMAIL_USER}>`,
      to: process.env.SUPPORT_EMAIL || 'support@yourapp.com', 
      replyTo: fromEmail,
      subject: `New Contact Message: ${subject}`,
      text: `
New message from ${fromName}

Email: ${fromEmail}
Phone: ${phone}

Subject: ${subject}

Message:
${message}
      `.trim(),
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 12px;">
          <h2 style="color: #3b82f6;">New Contact Form Submission</h2>
          <hr style="border: 1px solid #e0e0e0; margin: 20px 0;">
          
          <p><strong>Name:</strong> ${fromName}</p>
          <p><strong>Email:</strong> <a href="mailto:${fromEmail}" style="color: #3b82f6;">${fromEmail}</a></p>
          <p><strong>Phone:</strong> ${phone}</p>
          <p><strong>Subject:</strong> ${subject}</p>
          
          <hr style="border: 1px solid #e0e0e0; margin: 20px 0;">
          
          <h3>Message:</h3>
          <p style="background: #f8f9fa; padding: 16px; border-radius: 8px; white-space: pre-wrap;">
            ${message.replace(/\n/g, '<br>')}
          </p>
          
          <hr style="border: 1px solid #e0e0e0; margin: 30px 0;">
          <p style="color: #666; font-size: 12px;">
            This message was sent via the contact form on your website.
          </p>
        </div>
      `.trim(),
    };

    await transporter.sendMail(mailOptions);
    console.log('Contact email sent successfully');
  } catch (error) {
    console.error('Failed to send contact email:', error);
    throw new Error('Email sending failed');
  }
};