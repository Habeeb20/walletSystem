import mongoose from "mongoose";

const userSchema = new mongoose.Schema({

  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  fullName: { type: String, required: true },
  first_name: { type: String },
  last_name: { type: String },
  role:{type:String, default: "user"},
  phone: { type: String },
  username: { type: String, unique: true, sparse: true },
  twoFactorSecret: String,
  balance: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  isEmailVerified: { type: Boolean, default: false },
  emailVerificationCode: { type: String }, 
  biometricKeyId: { type: String },
  biometricPublicKey: { type: String },
  biometricChallenge: { type: String },
  biometricChallengeExpiresAt: { type: Date },
  passwordResetCodeHash: { type: String },
  passwordResetExpiresAt: { type: Date },
  paystackCustomerId: { type: String },
  wallet: {
    balance: { type: Number, default: 0 },
    transactions: {
      type: [
        {
          type: { type: String, enum: ['credit', 'debit', 'balance_check'] },
          amount: Number,
          provider: String,
          reference: String,
          status: { type: String, enum: ['pending', 'success', 'failed'] },
          details: mongoose.Schema.Types.Mixed,
          timestamp: { type: Date, default: Date.now },
        },
      ],
      default: [],
    },
  },

  virtualAccountDetails: {
  account_number: { type: String },
  account_name: { type: String },
  bank: { type: String },
},
paylonyVirtualAccountDetails: {
    account_number: { type: String },
    account_name: { type: String },
    bank_name: { type: String },
    provider: { type: String,  },
    domain: { type: String,  },
    reference: { type: String,  },
    assignment: { type: String, },
    status: { type: String,  },
    mandate: { reference: String, status: String, createdAt: Date },

  },

});


export default mongoose.model("User", userSchema)




